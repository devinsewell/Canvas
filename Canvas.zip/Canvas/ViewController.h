//
//  ViewController.h
//  Canvas
//
//  Created by devin sewell on 10/4/14.
//  Copyright (c) 2014 keois. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController{
    UIImageView *canvas;
    UIImageView *pic;
    CGSize screenSize;
    float red;
    float green;
    float blue;
    float opacity;
    float brush;
    CGPoint previousPoint;
    CGPoint previousPreviousPoint;
    CGPoint currentPoint;
    CGPoint mid1;
    CGPoint mid2;
    int erase;
    UIButton *btn;
    UIButton *btn2;
    UIImagePickerController *picker;
    UIView *holder;
    int iii;
}


@end

