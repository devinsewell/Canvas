//
//  ViewController.m
//  Canvas
//
//  Created by devin sewell on 10/4/14.
//  Copyright (c) 2014 keois. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

#pragma mark Private Helper function
CGPoint midPoint(CGPoint p1, CGPoint p2);
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    red = 0.0;
    green = 0.0;
    blue = 0.0;
    opacity = 1.0;
    brush = 3.0;
    CGRect screenBound = [[UIScreen mainScreen] bounds];
    screenSize = screenBound.size;
    
    //holder view
    holder = [[UIView alloc] initWithFrame:CGRectMake(0, 0, screenSize.width, screenSize.height)];
    [self.view addSubview:holder];
    
    //pic image
    pic = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, screenSize.width, screenSize.height)];
    [holder addSubview:pic];
    
    // canvas
    canvas = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, screenSize.width, screenSize.height)];
    [holder addSubview:canvas];
    
    //blocker
    UIView *blocker = [[UIView alloc] initWithFrame:CGRectMake(0, screenSize.height-49, screenSize.width, 49)];
    blocker.backgroundColor = [UIColor whiteColor];
    blocker.alpha = 0.9;
    [self.view addSubview:blocker];
    
    blocker = [[UIView alloc] initWithFrame:CGRectMake(0, 0, screenSize.width, 64)];
    blocker.backgroundColor = [UIColor whiteColor];
    blocker.alpha = 0.9;
    [self.view addSubview:blocker];
    
    //button
    btn = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    btn.frame = CGRectMake(0, 20, 44, 44);
    [btn addTarget:self action:@selector(picPhoto) forControlEvents:UIControlEventTouchUpInside];
    [btn setBackgroundImage:[UIImage imageNamed:@"btn_open"] forState:UIControlStateNormal];
    [self.view addSubview:btn];
    
    //button2
    btn2 = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    btn2.frame = CGRectMake(screenSize.width-44, 20, 44, 44);
    [btn2 addTarget:self action:@selector(share:) forControlEvents:UIControlEventTouchUpInside];
    [btn2 setBackgroundImage:[UIImage imageNamed:@"btn_share"] forState:UIControlStateNormal];
    btn2.hidden = YES;
    [self.view addSubview:btn2];
    
    //logo
    UIView *logo = [[UIView alloc] initWithFrame:CGRectMake(screenSize.width/2-66/2, 20, 66, 44)];
    logo.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"logo"]];
    [self.view addSubview:logo];
    
    //trash
    UIButton *trash = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    trash.frame = CGRectMake(screenSize.width-44, screenSize.height-49, 49, 49);
    [trash addTarget:self action:@selector(trash) forControlEvents:UIControlEventTouchUpInside];
    [trash setBackgroundImage:[UIImage imageNamed:@"icon_trash"] forState:UIControlStateNormal];
    [self.view addSubview:trash];
    
    //img picker
    picker = [[UIImagePickerController alloc] init];
    picker.delegate = self;
        
    iii = 0;
}

-(void)trash{
    canvas.image = nil;
    pic.image = nil;
}

- (IBAction)share:(id)sender {
    
    UIGraphicsBeginImageContextWithOptions(canvas.frame.size, NO, 0.0f);
    [holder.layer renderInContext:UIGraphicsGetCurrentContext()];
    UIImage *SaveImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    NSData *imageData = UIImageJPEGRepresentation(SaveImage,1.0);
    NSString *documentDirectory=[NSHomeDirectory() stringByAppendingPathComponent:@"Documents"];
    NSString *saveImagePath=[documentDirectory stringByAppendingPathComponent:@"Image.ig"];
    [imageData writeToFile:saveImagePath atomically:YES];
    NSURL *url=[NSURL fileURLWithPath:saveImagePath];
    
    NSString *shareString = @"Created with KEOIS Canvas";
    NSArray *objectsToShare = @[shareString,SaveImage];
    
    UIActivityViewController *controller = [[UIActivityViewController alloc] initWithActivityItems:objectsToShare applicationActivities:nil];
    
    [self presentViewController:controller animated:YES completion:nil];
    
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker {
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info {
    //[[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleBlackTranslucent animated:YES];
    [self dismissViewControllerAnimated:YES completion:nil];
    
    //file sel from picker
    UIImage *selImage = [[UIImage alloc] init];
    selImage = (UIImage*) [info objectForKey:UIImagePickerControllerOriginalImage];
    
    //set resize size
    int newWidth = 640;
    int newHeight = selImage.size.height/selImage.size.width*newWidth;
    CGSize itemSize = CGSizeMake(newWidth,newHeight);
    
    //resize the image
    UIGraphicsBeginImageContext(itemSize);
    CGRect imageRect = CGRectMake(0.0, 0.0, itemSize.width, itemSize.height);
    [selImage drawInRect:imageRect];
    selImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    //set image 1
    pic.clipsToBounds = YES;
    pic.contentMode = UIViewContentModeScaleAspectFill;
    pic.image = selImage;
    
    //nil image
    selImage = nil;
    
    //ui stuff
    btn2.hidden = NO;
    
}

-(void)picPhoto{
    picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    picker.allowsEditing = NO;
    picker.delegate = self;
    [self presentViewController:picker animated:YES completion:nil];
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    UITouch *touch = [touches anyObject];
    currentPoint = [touch locationInView:self.view];
    previousPreviousPoint = [touch locationInView:self.view];
    previousPoint = [touch locationInView:self.view];
    [self touchesMoved:touches withEvent:event];
}

CGPoint midPoint(CGPoint p1, CGPoint p2) {
    return CGPointMake((p1.x + p2.x) * 0.5, (p1.y + p2.y) * 0.5);
}

- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event {
    
    UITouch *touch = [touches anyObject];
    previousPreviousPoint = previousPoint;
    previousPoint = currentPoint;
    currentPoint = [touch locationInView:self.view];
    mid1 = midPoint(previousPoint, previousPreviousPoint);
    mid2 = midPoint(currentPoint, previousPoint);
     UIGraphicsBeginImageContextWithOptions(self.view.bounds.size, NO, 0.0);
    [canvas.image drawInRect:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height)];
    CGContextMoveToPoint(UIGraphicsGetCurrentContext(), mid1.x, mid1.y);
    CGContextSetLineCap(UIGraphicsGetCurrentContext(), kCGLineCapRound);
    CGContextSetLineWidth(UIGraphicsGetCurrentContext(), brush);
    CGContextSetRGBStrokeColor(UIGraphicsGetCurrentContext(), red, green, blue, opacity);
    if(erase == 1){
        CGContextSetRGBStrokeColor(UIGraphicsGetCurrentContext(), 0, 0, 0, 0);
        CGContextSetBlendMode(UIGraphicsGetCurrentContext(), kCGBlendModeCopy);
    }
    CGContextAddQuadCurveToPoint(UIGraphicsGetCurrentContext(), previousPoint.x, previousPoint.y, mid2.x, mid2.y);
    CGContextStrokePath(UIGraphicsGetCurrentContext());
    CGContextFlush(UIGraphicsGetCurrentContext());
    canvas.image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
}


-(void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event{
    UITouch *touch = [touches anyObject];
    previousPreviousPoint = previousPoint;
    previousPoint = currentPoint;
    currentPoint = [touch locationInView:self.view];
    mid1 = midPoint(previousPoint, previousPreviousPoint);
    mid2 = midPoint(currentPoint, previousPoint);
    UIGraphicsBeginImageContextWithOptions(self.view.bounds.size, NO, 0.0);
    [canvas.image drawInRect:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height)];
    CGContextMoveToPoint(UIGraphicsGetCurrentContext(), mid1.x, mid1.y);
    CGContextSetLineCap(UIGraphicsGetCurrentContext(), kCGLineCapRound);
    CGContextSetLineWidth(UIGraphicsGetCurrentContext(), brush);
    CGContextSetRGBStrokeColor(UIGraphicsGetCurrentContext(), red, green, blue, opacity);
    if(erase == 1){
        CGContextSetRGBStrokeColor(UIGraphicsGetCurrentContext(), 0, 0, 0, 0);
        CGContextSetBlendMode(UIGraphicsGetCurrentContext(), kCGBlendModeCopy);
    }
    CGContextAddQuadCurveToPoint(UIGraphicsGetCurrentContext(), previousPoint.x, previousPoint.y, mid2.x, mid2.y);
    CGContextStrokePath(UIGraphicsGetCurrentContext());
    CGContextFlush(UIGraphicsGetCurrentContext());
    canvas.image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    if(erase == 1){
        erase = 0;
        brush = 3.0;
    }else{
        //erase = 1;
        brush = 3.0;
    }
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
