//
//  AppDelegate.h
//  Canvas
//
//  Created by devin sewell on 10/4/14.
//  Copyright (c) 2014 keois. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

